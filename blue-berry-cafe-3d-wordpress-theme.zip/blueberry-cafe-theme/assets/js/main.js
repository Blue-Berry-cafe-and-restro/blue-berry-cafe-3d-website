document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.classList.toggle('menu-open', open);
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      nav.classList.remove('is-open'); toggle.setAttribute('aria-expanded', 'false'); document.body.classList.remove('menu-open');
    }));
  }

  // Lightweight 3D particle scene. If WebGL is unavailable, CSS artwork remains visible.
  const host = document.querySelector('.hero-art');
  if (!host || !window.THREE) return;
  try {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, host.clientWidth / host.clientHeight, 0.1, 100);
    camera.position.z = 8;
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.domElement.className = 'berry-canvas';
    host.prepend(renderer.domElement);
    scene.add(new THREE.AmbientLight(0xffffff, 1.3));
    const light = new THREE.PointLight(0x9b83ff, 2.2, 20); light.position.set(3, 4, 5); scene.add(light);
    const group = new THREE.Group(); scene.add(group);
    const geo = new THREE.SphereGeometry(0.22, 28, 28);
    const materials = [0x263f87, 0x426ca5, 0x6b58a5].map(c => new THREE.MeshStandardMaterial({ color:c, roughness:0.28, metalness:0.08 }));
    for (let i=0;i<18;i++) {
      const berry = new THREE.Mesh(geo, materials[i%materials.length]);
      const angle = i * 2.399;
      const radius = 1.45 + (i%4)*0.27;
      berry.position.set(Math.cos(angle)*radius, Math.sin(angle)*radius, (i%5-2)*0.24);
      berry.scale.setScalar(0.55 + (i%3)*0.17);
      group.add(berry);
    }
    let mx=0, my=0;
    host.addEventListener('pointermove', e => {
      const r=host.getBoundingClientRect(); mx=((e.clientX-r.left)/r.width-.5)*.35; my=((e.clientY-r.top)/r.height-.5)*.25;
    });
    function resize(){ const w=host.clientWidth,h=host.clientHeight; camera.aspect=w/h; camera.updateProjectionMatrix(); renderer.setSize(w,h); }
    window.addEventListener('resize', resize);
    function animate(t){ requestAnimationFrame(animate); group.rotation.y += 0.0018; group.rotation.x += (my-group.rotation.x)*0.025; group.rotation.y += mx*0.002; renderer.render(scene,camera); }
    animate(0);
  } catch(e) { /* CSS hero artwork is the graceful fallback. */ }
});
