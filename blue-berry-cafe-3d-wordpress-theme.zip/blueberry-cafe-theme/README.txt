BLUE_BERRY™ THE CAFÉ & RESTRO — WORDPRESS THEME
Version 1.0.0

INSTALLATION
1. In WordPress Admin, go to Appearance > Themes > Add New > Upload Theme.
2. Upload blue-berry-cafe-3d-wordpress-theme.zip.
3. Activate "Blue_Berry Cafe 3D".
4. Go to Appearance > Customize > Blue_Berry Contact Details and add the real phone, address, hours and Instagram URL.
5. Go to Appearance > Menus, create a menu and assign it to Primary Menu.
6. Go to Café Menu in the WordPress dashboard to add real dishes, descriptions, featured images and prices.

IMPORTANT
- This is a custom starter theme with an animated 3D-inspired hero and Three.js berry particle scene.
- Replace sample menu cards and gallery placeholders with the café's actual menu and photographs.
- The supplied logo is included as received (150x150 px); use a high-resolution transparent PNG or SVG for best results.
- Phone, exact address, opening hours, menu prices and ordering links are intentionally not invented.
- Three.js is loaded from a public CDN. The CSS artwork remains as a fallback if WebGL is unavailable.
- Test on a staging site before activating on a live production website.
