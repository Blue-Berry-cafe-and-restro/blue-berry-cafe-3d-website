<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Blue_Berry home">
    <?php if (has_custom_logo()) { the_custom_logo(); } else { ?>
      <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/blueberry-logo.png'); ?>" alt="Blue_Berry The Café & Restro">
    <?php } ?>
  </a>
  <button class="nav-toggle" aria-label="Open navigation" aria-expanded="false"><span></span><span></span></button>
  <nav class="main-nav" aria-label="Main navigation">
    <?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'fallback_cb'=>'blueberry_fallback_menu')); ?>
    <a class="nav-cta" href="#visit">Find Our Café <span>↗</span></a>
  </nav>
</header>
