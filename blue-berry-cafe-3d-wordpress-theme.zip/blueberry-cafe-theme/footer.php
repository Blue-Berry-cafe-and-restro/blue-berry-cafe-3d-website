<footer class="site-footer">
  <div class="footer-main"><a class="footer-brand" href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/blueberry-logo.png'); ?>" alt="Blue_Berry logo"></a><div class="footer-tagline">A little berry.<br><em>A lot of happiness.</em></div><div class="footer-social"><span>FOLLOW THE GOOD MOOD</span><a href="<?php echo esc_url(get_theme_mod('blueberry_instagram','https://www.instagram.com/blue_berrythecafe/')); ?>" target="_blank" rel="noopener">Instagram ↗</a></div></div>
  <div class="footer-bottom"><span>© <?php echo esc_html(date('Y')); ?> Blue_Berry™ The Café & Restro.</span><span>Made with a little extra love. ✳</span><a href="#home">BACK TO TOP ↑</a></div>
</footer>
<?php wp_footer(); ?>
</body></html>
