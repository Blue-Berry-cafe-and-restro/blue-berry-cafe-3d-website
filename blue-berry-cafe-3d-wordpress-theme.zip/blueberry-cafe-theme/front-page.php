<?php get_header(); ?>
<main>
<section class="hero" id="home">
  <div class="hero-glow"></div><div class="hero-grain"></div>
  <div class="hero-copy">
    <p class="eyebrow"><span class="eyebrow-dot"></span> THE CAFÉ & RESTRO · ANJAR</p>
    <h1>A little berry.<br><em>A lot of happiness.</em></h1>
    <p class="hero-intro">Good food, refreshing sips and moments worth sharing. Welcome to your happy place.</p>
    <div class="hero-actions"><a class="button button-primary" href="#menu">Explore the menu <span>↗</span></a><a class="text-link" href="#story">Discover our story <span>↓</span></a></div>
    <div class="hero-note"><span class="note-line"></span><span>MADE FOR GOOD MOODS & GREAT MOMENTS</span></div>
  </div>
  <div class="hero-art" aria-label="Decorative animated blueberry scene">
    <div class="orb orb-one"></div><div class="orb orb-two"></div><div class="orb orb-three"></div>
    <div class="berry berry-a"></div><div class="berry berry-b"></div><div class="berry berry-c"></div>
    <div class="berry berry-d"></div><div class="leaf leaf-a"></div><div class="leaf leaf-b"></div>
    <div class="drink-shadow"></div>
    <div class="drink"><div class="drink-lid"></div><div class="drink-straw"></div><div class="drink-liquid"></div><div class="drink-label">BLUE<br><b>BERRY</b><small>GOOD MOOD CLUB</small></div><div class="drink-shine"></div></div>
    <div class="art-caption"><span>01 /</span> THE SIGNATURE EXPERIENCE</div>
  </div>
  <a class="scroll-cue" href="#story"><span></span> SCROLL TO EXPLORE</a>
</section>

<section class="intro section-pad" id="story">
  <div class="section-kicker">A PLACE TO PAUSE & ENJOY</div>
  <div class="intro-grid">
    <h2>More than a café.<br><em>Your happy place.</em></h2>
    <div class="intro-text"><p>Some moments deserve great food, refreshing drinks and even better company. At Blue_Berry, we bring them together in one welcoming space in Anjar.</p><a class="under-link" href="#visit">Come say hello <span>↗</span></a></div>
  </div>
  <div class="intro-stamp"><span>GOOD</span><b>VIBES</b><span>ONLY</span></div>
</section>

<section class="menu-section section-pad" id="menu">
  <div class="section-top"><div><div class="section-kicker">A LITTLE SOMETHING FOR EVERYONE</div><h2>Made to make<br><em>you smile.</em></h2></div><p>Explore the flavours and favourites<br>waiting for you at Blue_Berry.</p></div>
  <div class="menu-grid">
  <?php
  $items = new WP_Query(array('post_type'=>'berry_menu','posts_per_page'=>6,'post_status'=>'publish'));
  if ($items->have_posts()) : $i=0; while ($items->have_posts()) : $items->the_post(); $i++; ?>
    <article class="menu-card"><a href="<?php the_permalink(); ?>" class="menu-image"><?php if (has_post_thumbnail()) the_post_thumbnail('large'); else echo '<span class="image-placeholder">Add a menu photo</span>'; ?><span class="menu-index">0<?php echo esc_html($i); ?></span></a><div class="menu-card-info"><div><h3><?php the_title(); ?></h3><p><?php echo esc_html(get_the_excerpt()); ?></p></div><?php $price=get_post_meta(get_the_ID(),'_blueberry_price',true); if ($price) echo '<span class="price">₹' . esc_html($price) . '</span>'; ?></div></article>
  <?php endwhile; wp_reset_postdata(); else :
    $samples = array(array('Coffee & coolers','Your refreshing little pick-me-up.'),array('Bites & burgers','Big flavours for happy cravings.'),array('Sweet treats','A sweet finish to a lovely day.'));
    foreach($samples as $i=>$sample): ?>
    <article class="menu-card sample-card"><div class="sample-art sample-<?php echo esc_attr($i+1); ?>"><span><?php echo esc_html('0'.($i+1)); ?></span><b><?php echo esc_html($sample[0]); ?></b></div><div class="menu-card-info"><div><h3><?php echo esc_html($sample[0]); ?></h3><p><?php echo esc_html($sample[1]); ?></p></div></div></article>
  <?php endforeach; endif; ?>
  </div>
  <p class="menu-admin-note">Menu items and prices can be added from WordPress Admin → Café Menu.</p>
</section>

<section class="quote-band"><div class="quote-berry">✳</div><p>Good food tastes even better<br>when shared with <em>good people.</em></p><span>THE BLUE_BERRY FEELING</span></section>

<section class="gallery-section section-pad" id="gallery">
  <div class="section-top"><div><div class="section-kicker">A FEAST FOR THE EYES</div><h2>Moments worth<br><em>coming back for.</em></h2></div><a class="under-link" href="<?php echo esc_url(get_theme_mod('blueberry_instagram','https://www.instagram.com/blue_berrythecafe/')); ?>" target="_blank" rel="noopener">Follow on Instagram ↗</a></div>
  <div class="gallery-grid">
    <div class="gallery-tile tile-large"><div class="gallery-placeholder"><span>01</span><b>Your café<br>interior photo</b></div></div>
    <div class="gallery-tile"><div class="gallery-placeholder tile-blue"><span>02</span><b>Your favourite<br>food photo</b></div></div>
    <div class="gallery-tile"><div class="gallery-placeholder tile-mint"><span>03</span><b>Your signature<br>drink photo</b></div></div>
  </div>
  <p class="menu-admin-note">Replace these placeholders with real Blue_Berry café and food photography.</p>
</section>

<section class="visit-section section-pad" id="visit">
  <div class="visit-card"><div class="visit-copy"><div class="section-kicker">YOUR TABLE IS WAITING</div><h2>Let's make it<br><em>a berry good day.</em></h2><p>Drop by, bring your favourite people and enjoy a little time for yourself.</p>
    <div class="visit-details"><div><span>FIND US</span><b><?php echo esc_html(get_theme_mod('blueberry_address','Anjar, Gujarat, India')); ?></b></div><div><span>OPENING HOURS</span><b><?php echo esc_html(get_theme_mod('blueberry_hours','Please update opening hours')); ?></b></div><?php if(get_theme_mod('blueberry_phone')): ?><div><span>CALL / WHATSAPP</span><b><?php echo esc_html(get_theme_mod('blueberry_phone')); ?></b></div><?php endif; ?></div>
    <div class="hero-actions"><a class="button button-dark" href="https://www.google.com/maps/search/?api=1&query=<?php echo rawurlencode(get_theme_mod('blueberry_address','Blue_Berry The Cafe Anjar Gujarat')); ?>" target="_blank" rel="noopener">Get directions ↗</a><?php if(get_theme_mod('blueberry_phone')): ?><a class="text-link" href="https://wa.me/<?php echo esc_attr(preg_replace('/[^0-9]/','',get_theme_mod('blueberry_phone'))); ?>">WhatsApp us ↗</a><?php endif; ?></div>
  </div><div class="visit-art"><div class="visit-circle">GOOD<br><b>VIBES</b><br>LIVE HERE</div><span class="visit-spark">✳</span></div></div>
</section>
</main>
<?php get_footer(); ?>
