<?php
if (!defined('ABSPATH')) exit;

function blueberry_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array('height' => 160, 'width' => 160, 'flex-height' => true, 'flex-width' => true));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    register_nav_menus(array('primary' => __('Primary Menu', 'blueberry-cafe')));
}
add_action('after_setup_theme', 'blueberry_theme_setup');

function blueberry_enqueue_assets() {
    wp_enqueue_style('blueberry-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700;800&display=swap', array(), null);
    wp_enqueue_style('blueberry-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_style('blueberry-main', get_template_directory_uri() . '/assets/css/main.css', array('blueberry-style'), '1.0.0');
    wp_enqueue_script('blueberry-three', 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r152/three.min.js', array(), '0.152.0', true);
    wp_enqueue_script('blueberry-main', get_template_directory_uri() . '/assets/js/main.js', array('blueberry-three'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'blueberry_enqueue_assets');

function blueberry_customize_register($wp_customize) {
    $wp_customize->add_section('blueberry_contact', array('title' => __('Blue_Berry Contact Details', 'blueberry-cafe'), 'priority' => 30));
    $fields = array(
        'blueberry_phone' => array('Phone / WhatsApp', ''),
        'blueberry_address' => array('Full café address', 'Anjar, Gujarat, India'),
        'blueberry_hours' => array('Opening hours', 'Please update opening hours'),
        'blueberry_instagram' => array('Instagram URL', 'https://www.instagram.com/blue_berrythecafe/'),
    );
    foreach ($fields as $id => $data) {
        $wp_customize->add_setting($id, array('default' => $data[1], 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control($id, array('label' => $data[0], 'section' => 'blueberry_contact', 'type' => 'text'));
    }
}
add_action('customize_register', 'blueberry_customize_register');

function blueberry_menu_post_type() {
    register_post_type('berry_menu', array(
        'labels' => array('name' => 'Café Menu', 'singular_name' => 'Menu Item', 'add_new_item' => 'Add Menu Item'),
        'public' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-food',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'has_archive' => false,
        'rewrite' => array('slug' => 'cafe-menu-item')
    ));
}
add_action('init', 'blueberry_menu_post_type');

function blueberry_menu_price_meta() {
    add_meta_box('blueberry_price', 'Menu Item Price', 'blueberry_price_box', 'berry_menu', 'side');
}
add_action('add_meta_boxes', 'blueberry_menu_price_meta');
function blueberry_price_box($post) {
    wp_nonce_field('blueberry_save_price', 'blueberry_price_nonce');
    $price = get_post_meta($post->ID, '_blueberry_price', true);
    echo '<label for="blueberry_price_field">Price (e.g. 199)</label><input style="width:100%;margin-top:8px" id="blueberry_price_field" name="blueberry_price_field" value="' . esc_attr($price) . '" />';
}
function blueberry_save_price($post_id) {
    if (!isset($_POST['blueberry_price_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['blueberry_price_nonce'])), 'blueberry_save_price')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (isset($_POST['blueberry_price_field'])) update_post_meta($post_id, '_blueberry_price', sanitize_text_field(wp_unslash($_POST['blueberry_price_field'])));
}
add_action('save_post_berry_menu', 'blueberry_save_price');

function blueberry_fallback_menu() {
    echo '<ul class="nav-links"><li><a href="' . esc_url(home_url('/')) . '">Home</a></li><li><a href="#story">Our Story</a></li><li><a href="#menu">Menu</a></li><li><a href="#gallery">Gallery</a></li><li><a href="#visit">Visit Us</a></li></ul>';
}
